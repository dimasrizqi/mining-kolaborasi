<?php $__env->startSection('title', 'Data Dasar Pemining'); ?>

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
        <div class="row">
            <div class="col-lg-12">
        <h1>Informasi Dasar pemining</h1> 
        </div>
        
        </div>
    </section>
    <div class="section-body">
        
        <div class="row">
            
            <div class="col-12 col-md-12 col-lg-12">
                <div class="card">
                    <!--<div class="table-responsive">-->
                    <div>
                        <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-success">
                            <p><?php echo e($message); ?></p>
                        </div>
                        <?php endif; ?>
                        <?php if($message = Session::get('deleted')): ?>
                        <div class="alert alert-danger">
                            <p><?php echo e($message); ?></p>
                        </div>
                        <?php endif; ?>
                        <table class="table table-striped table-bordered">
                                <tr>
                                    <td> Nama </td>
                                    <td ><?php echo e($datauser[0]->name); ?> </td>
                                </tr>
                                <tr>
                                    <td> Hashrate VGA </td>
                                    <td ><?php echo e($datauser[0]->hashrate); ?> </td>
                                </tr>
                                <tr>
                                    <td> Type VGA </td>
                                    <td ><?php echo e($datauser[0]->vga); ?> </td>
                                </tr>
                                <tr>
                                    <td> Fee </td>
                                    <td ><?php echo e($datauser[0]->fee); ?> </td>
                                </tr>
                                <tr>
                                    <td> Total coin </td>
                                    <td > Total koinnya</td>
                                </tr>
                                <tr>
                                    <td> Withdraw coin </td>
                                    <td > Total koinnya</td>
                                </tr>
                                <tr>
                                    <td> Selisih coin di Dimas </td>
                                    <td > Total koinnya</td>
                                </tr>
                                <tr>
                                    <td> Total Rupiah </td>
                                    <td >Total Rupiahnya</td>
                                </tr>
                                <tr>
                                    <td> Withdraw Rupiah </td>
                                    <td >Total Rupiahnya }}</td>
                                </tr>
                                
                                <tr>
                                    <td> Selisih Rupiah di Dimas</td>
                                    <td >Total Rupiahnya</td>
                                </tr>
                        </table>
                    </div>
                    <div class="col-md-12">
                                    
                            
                                </div>
            </div>

        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('page-script'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/izbuqebp/mining.tamiya.id/resources/views/mining/data_dasar.blade.php ENDPATH**/ ?>