<!DOCTYPE html>
<html lang="en">
    <!-- </div> Created By <a href="https://www.instagram.com/dimasrizqi">RADJA RIZQI RAMADHAN </a>  -->
<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
  <title><?php echo $__env->yieldContent('title'); ?> - Futami </title>

  <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/all.css')); ?>" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">

  
  <?php echo $__env->yieldContent('page-styles'); ?>

  
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/components.css')); ?>">
</head>

<body class="sidebar-gone sidebar-mini">
  <div id="app">
    <div class="main-wrapper">
      <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      
      <div class="main-content">
        
        <?php echo $__env->yieldContent('content'); ?>

      </div>
      <footer class="main-footer">
        <div class="footer-left">
            Futami &copy; <?php echo e(date('Y')); ?> 
              
        </div>
        
      </footer>
    </div>
  </div>

  <!-- General JS Scripts -->
  <script src="<?php echo e(asset('assets/js/jquery-3.3.1.min.js')); ?>" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
  <script src="<?php echo e(asset('assets/js/popper.min.js')); ?>" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
  <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  <script src="<?php echo e(asset('assets/js/jquery.nicescroll.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/moment.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/stisla.js')); ?>"></script>

  

  
  <script src="<?php echo e(asset('assets/js/scripts.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>

   <!-- Page Specific JS File  -->
   
  <?php echo $__env->yieldPushContent('page-scripts'); ?>
</body>
</html>
<?php /**PATH /home/izbuqebp/short.tamiya.id/resources/views/layouts/master.blade.php ENDPATH**/ ?>