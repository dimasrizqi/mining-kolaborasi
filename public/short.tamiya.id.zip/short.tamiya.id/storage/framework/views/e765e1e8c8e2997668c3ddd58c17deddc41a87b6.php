<?php $__env->startSection('title', 'Lihat User'); ?>

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <a href="<?php echo e(route('tambah-user')); ?>" class="btn btn-info">Tambah </a>
        </div>
        <div class="section-body">
            <div class="table-responsive">
                <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success">
                    <p><?php echo e($message); ?></p>
                </div>
                <?php endif; ?>
                <?php if($message = Session::get('deleted')): ?>
                <div class="alert alert-danger">
                    <p><?php echo e($message); ?></p>
                </div>
                <?php endif; ?>
                
                <table class="table table-bordered table-striped">
                    <tr>
                        <th width="50px">NO.</th>
                        <th >Nama</th>
                        <th >Hashrate</th>
                        <th >Action</th>
                    </tr>
                    <?php $__currentLoopData = $datauser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $datanya): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td> <?php echo e($no + 1); ?> </td>
                            <td><?php echo e($datanya->name); ?> </td>
                            <td><?php echo e($datanya->hashrate); ?></td>
                            <td>
                                
                                <form class="pull-left" action="<?php echo e(route('userdel',$datanya->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger">Delete</button>
                                    <a class="btn btn-warning" href="<?php echo e(route ('resetpass',$datanya->id)); ?>">reset password </a>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
                <i>reset password akan mengembalikan password user menjadi <b>12345678</b></i>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('page-script'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/izbuqebp/short.tamiya.id/resources/views/otentikasi/index.blade.php ENDPATH**/ ?>