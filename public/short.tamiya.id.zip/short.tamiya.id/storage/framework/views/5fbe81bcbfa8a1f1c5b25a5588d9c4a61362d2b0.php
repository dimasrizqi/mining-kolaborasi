<?php $__env->startSection('title', 'Profile User'); ?>

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h1>Profile User</h1>
        </div>
    </section>
    <div class="section-body">
        <div class="row">
            <div class="col-12 col-md-12 col-lg-12">
                <div class="card">

                    <form action="<?php echo e(route('profile-user-simpan')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php $__currentLoopData = $datauser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Nama Lengkap</label>
                                        <input value="<?php echo e($item->name); ?>" type="text" placeholder="Input Nama Lengkap" name="name" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>No HP Anda</label>
                                        <input value="<?php echo e($item->no_hp); ?>" type="text" name="no_hp" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Ganti Password</label>
                                        <input type="text" placeholder="Silahkan isi untuk mengganti password" name="password" class="form-control">
                                    </div>
                                </div>
                                
                                
                                
                                <div class="col-md-12">
                                    <div class="card-footer text-right">
                                        <button class="btn btn-info mr-1" type="submit">Update</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </form>
                </div>
                
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('page-script'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/izbuqebp/mining.tamiya.id/resources/views/otentikasi/profile.blade.php ENDPATH**/ ?>