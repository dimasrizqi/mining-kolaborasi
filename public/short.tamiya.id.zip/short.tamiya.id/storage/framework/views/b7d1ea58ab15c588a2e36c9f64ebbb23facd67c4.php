<?php $__env->startSection('title', 'Data Shortlink'); ?>

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
        <div class="row">
            <div class="col-md-12">
            <h1><a href="<?php echo e(route('shortlink.create')); ?>" class="btn btn-info">Tambah Shortlink</a>
            <a href="<?php echo e(route('shortlink.print')); ?>" class="btn btn-success">Print Shortlink</a> 
            </h1> 
            </div>
            
        </div>
        
        </div>
    </section>
    <div class="section-body">
        
        <div class="row">
            
            <div class="col-12 col-md-12 col-lg-12">
                <div class="card">
                    <div class="table-responsive">
                        <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-success">
                            <p><?php echo e($message); ?></p>
                        </div>
                        <?php endif; ?>
                        <?php if($message = Session::get('deleted')): ?>
                        <div class="alert alert-danger">
                            <p><?php echo e($message); ?></p>
                        </div>
                        <?php endif; ?>
                        <table class="table table-striped table-sm">
                            <tr>
                                <th >no</th>
                                <th width="300 px">Nama Link </th>
                                <th >Url Asli</th>  
                                <th >Shortlink</th>  
                                <th width="300 px">Action  </th>
                            </tr>
                            <?php $__currentLoopData = $datashortlink; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td> <?php echo e($no+1); ?> </td>
                                    <td ><?php echo e($item->nama_link); ?> </td>
                                    <td ><a href="<?php echo e($item->url_asli); ?>" target="_blank"><?php echo e($item->url_asli); ?></a> </td>
                                    <td > <a href="<?php echo e($item->shortlink); ?>" target="_blank"><?php echo e($item->shortlink); ?> </a> </td>
                                    <td>
                                        
                                        <form class="pull-left" action="<?php echo e(route('shortlink.destroy',$item->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <a class="btn btn-primary" href="<?php echo e(route('shortlink.edit',$item->shortlink)); ?>">Show</a>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-disable">Delete</button>
                                        </form>
                                        
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                    <div class="col-md-12">
                                    
                            <?php echo e($datashortlink->onEachSide(5)->links()); ?>

                                </div>
            </div>

        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('page-script'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/izbuqebp/short.tamiya.id/resources/views/shortlink/index.blade.php ENDPATH**/ ?>