<?php $__env->startSection('title', 'Data mining'); ?>

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
        <div class="row">
            <div class="col-md-6">
        <h1><a href="<?php echo e(route('mining.create')); ?>" class="btn btn-info">Tambah Data Mining</a> </h1> 
                
            </div>
            <div class="col-md-6">
                Total Mining <?php echo e(number_format($jumlah_coin,8)); ?>

            </div>
        </div>
        
        </div>
    </section>
    <div class="section-body">
        
        <div class="row">
            
            <div class="col-12 col-md-12 col-lg-12">
                <div class="card">
                    <div class="table-responsive">
                        <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-success">
                            <p><?php echo e($message); ?></p>
                        </div>
                        <?php endif; ?>
                        <?php if($message = Session::get('deleted')): ?>
                        <div class="alert alert-danger">
                            <p><?php echo e($message); ?></p>
                        </div>
                        <?php endif; ?>
                        <table class="table table-striped table-md">
                            <tr>
                                <th >Tgl</th>
                                <th width="300 px">Hasil Mining </th>
                                <th >Kurs</th>  
                                <th width="300 px">Action  </th>
                            </tr>
                            <?php $__currentLoopData = $datamining; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td> <?php echo e($item->timestamp); ?> </td>
                                    <td ><?php echo e($item->hasil_mining); ?> </td>
                                    <td >Rp. <?php echo number_format($item->kurs,0,',','.'); ?> </td>
                                    <td>
                                        
                                        <form class="pull-left" action="<?php echo e(route('mining.destroy',$item->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <a class="btn btn-primary" href="<?php echo e(route('mining.edit',$item->id)); ?>">Show</a>
                                            <a class="btn btn-success" href="<?php echo e(route('mining.kalkulasi',$item->id)); ?>">Kalkulasi</a>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-disable">Delete</button>
                                        </form>
                                        
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                    <div class="col-md-12">
                                    
                            <?php echo e($datamining->onEachSide(5)->links()); ?>

                                </div>
            </div>

        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('page-script'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/izbuqebp/mining.tamiya.id/resources/views/mining/index.blade.php ENDPATH**/ ?>