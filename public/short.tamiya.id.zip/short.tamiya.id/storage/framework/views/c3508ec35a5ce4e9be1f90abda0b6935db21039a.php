<?php $__env->startSection('title', 'Tambah User'); ?>

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h1>Input User</h1>
        </div>
    </section>
    <div class="section-body">
        <div class="row">
            <div class="col-12 col-md-12 col-lg-12">
                <div class="card">

                    <form action="<?php echo e(route('tambah-user-simpan')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="creator" value="<?php if($message = Session::get('id_user')): ?>
                        <?php echo e($message); ?>

                        <?php endif; ?>">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>* Nama Lengkap</label>
                                        <input type="text" placeholder="Input Nama Lengkap" name="name" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>* No HP</label>
                                        <input type="text" placeholder="Masukan No HP " name="no_hp" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>* Hashrate</label>
                                        <input type="number" step="0.01" placeholder="Masukan Hashrate " name="hashrate" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>* Status User</label>
                                        <select class="form-control" name="status" >
                                            <option value=""></option> 
                                            <option value="1">Aktif</option> 
                                            <option value="2">Non Aktif</option> 
                                        </select><br>
                                        <label><i>password default : 12345678</i></label>
                                    </div>
                                </div>
                                

                                <div class="col-md-12">
                                    <div class="card-footer text-right">
                                        <button class="btn btn-primary mr-1" type="submit">Submit</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                
                </form>
            </div>

        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('page-script'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/izbuqebp/mining.tamiya.id/resources/views/otentikasi/tambah-user.blade.php ENDPATH**/ ?>