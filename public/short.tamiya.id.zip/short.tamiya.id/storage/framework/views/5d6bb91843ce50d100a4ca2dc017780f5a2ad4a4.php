<?php $__env->startSection('title', 'Kalkulasi Hasil mining'); ?>

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h1>Hasil kalkulasi Mining <?php echo e(Carbon\Carbon::now()->isoFormat('D MMMM Y')); ?></h1>
        </div>
    </section>
    <div class="section-body">
        <div class="row">
            <div class="col-12 col-md-12 col-lg-12">
                <div class="card">

                    <form action="<?php echo e(route('mining.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        
                        <div class="card-body">
                            <div class="row">
                                
                                <?php if($message = Session::get('failed')): ?>
                                <div class="col-md-12">
                                    <div class="alert alert-danger">
                                        <p><?php echo e($message); ?></p>
                                    </div>
                                </div>
                                <?php endif; ?>
                                
                                <div class="col-md-12">
                                    
                                        Kurs Saat Tukar Hasil Payout = <b><u>Rp <?php echo e($datamining[0]->kurs); ?></u></b><br>
                                        Hasil Mining = <b><u><?php echo e($datamining[0]->hasil_mining); ?></u></b> ETH
                                   
                                    <div class="table-responsive">
                                   <table class="table table-md table-bordered table-striped">
                                        <tr>
                                            <th width="50px">NO.</th>
                                            <th >Nama</th>
                                            <th >Hashrate</th>
                                            <th width="50px">Persentase Mining</th>
                                            <th >Hasil Coin</th>
                                            <th >Fee Payout </th>
                                            <th >Hasil Rupiah </th>
                                            
                                        </tr>
                                        <form action="<?php echo e(route('mining.proses')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php $__currentLoopData = $datauser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $datanya): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($no + 1); ?> </td>
                                                <td><?php echo e($datanya->name); ?> </td>
                                                <td><?php echo e($datanya->hashrate); ?> Mhs</td>
                                                <td><?php echo e(number_format($totalpersen = ($datanya->hashrate/$total_hashrate) *100,2)); ?> %</td>
                                                <td><?php echo e(number_format($hasil_koin = (($totalpersen/100)*$datamining[0]->hasil_mining)- ((($totalpersen/100)*$datamining[0]->hasil_mining)*($datanya->fee/100)),8)); ?></td>
                                                <td>
                                                    <?php if($datanya->payout_rupiah == 1): ?>
                                                       Rp <?php echo e($fee_exchange = ($dataexchange[0]->fee / $total_payout_rupiah)); ?>

                                                    <?php elseif($datanya->payout_rupiah == 0): ?>
                                                        <?php echo e($fee_exchange = 0); ?>

                                                    <?php else: ?>
                                                        Error - tidak ada pilihan
                                                    <?php endif; ?>  
                                                </td>
                                                <td align="right">Rp. <?php echo number_format(($hasil_koin*$datamining[0]->kurs)-$fee_exchange,0,',','.'); ?> </td>    
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                        </form>
                                    </table>
                                    <div class="col-md-12">
                                    <div class="card-footer text-right">
                                        <button class="btn btn-primary mr-1" type="submit">Proses</button>
                                    </div>
                                </div>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                
                </form>
            </div>

        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('page-scripts'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/izbuqebp/mining.tamiya.id/resources/views/mining/kalkulasi.blade.php ENDPATH**/ ?>