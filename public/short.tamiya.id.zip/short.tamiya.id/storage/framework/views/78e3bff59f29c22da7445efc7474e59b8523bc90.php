<!DOCTYPE html>
<html>
  <head>
  </head>
  <body>
      <table border='1' margin="10">
        <?php $__currentLoopData = $datashortlink; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <?php if($no % 7 ==0): ?>
            <tr>
            <td align="center"> <img width="100" src="https://chart.googleapis.com/chart?chd=h&chs=70x70&cht=qr&chl=<?php echo e($host); ?>/<?php echo e($item->shortlink); ?>"></img><br>
            <?php echo e($item->nama_link); ?> 
            </td>
        <?php else: ?>
            <td align="center"> <img width="100" src="https://chart.googleapis.com/chart?chd=l&chs=70x70&cht=qr&chl=<?php echo e($host); ?>/<?php echo e($item->shortlink); ?>"></img><br>
            <?php echo e($item->nama_link); ?> 
            </td>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
        </tr>
      </table>
  </body>
</html><?php /**PATH /home/izbuqebp/short.tamiya.id/resources/views/shortlink/print.blade.php ENDPATH**/ ?>