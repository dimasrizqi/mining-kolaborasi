<?php $__env->startSection('title', 'Informasi Shortlink'); ?>

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
        
        <h1>Silahkan ubah dan klik simpan atau <a href="<?php echo e(route('shortlink.index')); ?>" class="btn btn-info">Kembali</a> </h1> 
        </div>
    </section>
    <div class="section-body">
        
        <div class="row">
            <div class="col-6 col-md-6 col-lg-6">
                <div class="card">
                    <?php if($message = Session::get('success')): ?>
                    
                    <div class="alert alert-success">
                        
                        <p><?php echo e($message); ?></p>
                        
                    </div>
                    
                    <?php endif; ?>
                   
                    <form action="<?php echo e(route('shortlink.update',$datashortlink->id)); ?>" method="POST">
                        <?php echo method_field('PUT'); ?>
                        
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Shortlink</label><br>
                                        <input type="text" name="shortlink" value="<?php echo e($datashortlink->shortlink); ?>" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Nama Shortlink</label><br>
                                        <input type="text" name="nama_link" value="<?php echo e($datashortlink->nama_link); ?>" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Link asli</label><br>
                                        <textarea name="url_asli" class="form-control"><?php echo e($datashortlink->url_asli); ?></textarea>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group text-left">
                                        <button type="submit" class="btn btn-success">Simpan</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php echo csrf_field(); ?>
                        
                        </form>
            </div>

        </div>
            <div class="col-6 col-md-6 col-lg-6">
                <div class="card">
                    <div class="">
                        
                        <p>qrcode untuk link <a href="<?php echo e($host); ?>/<?php echo e($datashortlink->shortlink); ?>"><?php echo e($host); ?>/<?php echo e($datashortlink->shortlink); ?></a> </p>
                        <p>
                        
                        </p>
                        
                    </div>
                        <img width="200px" src="https://chart.googleapis.com/chart?chd=h&chs=300x300&cht=qr&chl=<?php echo e($host); ?>/<?php echo e($datashortlink->shortlink); ?>"></img>
            </div>

        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('page-script'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/izbuqebp/short.tamiya.id/resources/views/shortlink/edit.blade.php ENDPATH**/ ?>