<?php $__env->startSection('title', 'Input Short link'); ?>

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
           <h1>Input Short link </h1>
        </div>
    </section>
    <div class="section-body">
        <div class="row">
            <div class="col-12 col-md-12 col-lg-12">
                <div class="card">

                    <form action="<?php echo e(route('shortlink.store')); ?> " method="POST">
                        <?php echo csrf_field(); ?>
                        
                        <div class="card-body">
                            <div class="row">
                                
                                <?php if($message = Session::get('failed')): ?>
                                <div class="col-md-12">
                                    <div class="alert alert-danger">
                                        <p><?php echo e($message); ?></p>
                                    </div>
                                </div>
                                <?php endif; ?>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>URL Asli </label>
                                        <textarea placeholder="Masukan Url yang akan dipendekkan" name="url_asli" class="form-control" required> </textarea>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Nama Shortlink</label>
                                        <input type="text" required placeholder="Nama Untuk Shortlink" name="nama_link" class="form-control" >
                                    </div>
                                </div>
                                
                                <div class="col-md-12">
                                    <div class="card-footer text-right">
                                        <button class="btn btn-primary mr-1" type="submit">Submit</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                
                </form>
            </div>

        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('page-scripts'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/izbuqebp/short.tamiya.id/resources/views/shortlink/create.blade.php ENDPATH**/ ?>